import { StatusBar } from "expo-status-bar";
import React, { useEffect, useState } from "react";
import {
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import header from "./header_common.png";
import pause from "./pause-outline-filled.png";
import edit from "./edit-solid-1.png";
import { BarCodeScanner } from "expo-barcode-scanner";
import solidcancel from "./android-cancel.png";

function SixthSlide() {
  const [scanned, setScanned] = useState(false);
  const [hasPermission, setHasPermission] = useState(null);
  const [assert, setAssert] = useState([]);
  const [data, setData]=useState("")
  const handleAddAssert = () => {
    const updatedArray = [...assert, [data]];
    setAssert(updatedArray);
    console.log(assert)
  };

  const handledelete = (i) => {
    const deleteassert = [...assert];
    deleteassert.splice(i, 1);
    setAssert(deleteassert);
  };

  useEffect(() => {
    const getBarCodeScannerPermissions = async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === "granted");
    };

    getBarCodeScannerPermissions();
  }, []);

  const handleBarCodeScanned = ({ type, data }) => {
    setScanned(true);
    alert(`Bar code with type ${type} and data ${data} has been scanned!`);
    console.log(data)
    setData(data)
    handleAddAssert();
  };

  if (hasPermission === null) {
    return <Text>Requesting for camera permission</Text>;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }

  return (
    <View width="100%" height="100%" style={{ backgroundColor: "#F9F9F8" }}>
      <View
        style={{
          flexDirection: "row",
          marginTop: 10,
        }}
      >
        <TouchableOpacity style={styles.menu}>
          <MaterialIcons name={"arrow-back-ios"} size={25} />
        </TouchableOpacity>
        <Image
          style={{
            width: 20,
            height: 20,
            marginTop: 13,
            marginLeft: 18,
            marginRight: 5,
          }}
          source={header}
        ></Image>

        <Text style={{ fontSize: 20, marginTop: 7 }}>admin admin</Text>
      </View>
      <View style={{ marginTop: 18, flexDirection: "row" }}>
        <Text
          style={{
            fontSize: 23,
            fontWeight: "900",
            marginLeft: 120,
            marginRight: 30,
          }}
        >
          Scan QR
        </Text>
        <Image
          style={{
            width: 20,
            height: 20,
            marginTop: 6,
            marginLeft: 18,
            marginRight: 5,
            justifyContent: "flex-end",
          }}
          source={pause}
        ></Image>
        <Image
          style={{
            width: 20,
            height: 20,
            marginTop: 6,
            marginLeft: 18,
            marginRight: 5,
            justifyContent: "flex-end",
          }}
          source={edit}
        ></Image>
      </View>
      <View
        style={{ borderWidth: 1,padding:2,margin: 20, borderRadius: 10 }}
      >
        <View style={{ paddingTop: 180, paddingBottom:180, }}>
          <BarCodeScanner
          onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
          style={StyleSheet.absoluteFillObject}
        />
        </View>
      </View>
      <View>
        <FlatList
          data={assert}
          renderItem={({ item, index }) => {
            return (
              <View style={{ paddingHorizontal: 10, flexDirection: "row" }}>
                <View
                  style={{
                    flex: 1,
                    textAlign: "center",
                    borderWidth: 1,
                    borderColor: "#AAAA9F",
                    backgroundColor: "#F9F9F8",
                    borderRadius: 10,
                    padding: 5,
                    marginEnd: 6,
                  }}
                >
                  <View style={{ flexDirection: "row" }}>
                    <View>
                      <Text>{item}</Text>
                      <Text>(0)</Text>
                    </View>
                    <Image
                      style={{
                        width: 20,
                        height: 20,
                        marginTop: 18,
                        marginLeft: 37,
                      }}
                      source={solidcancel}
                    ></Image>
                  </View>
                </View>
              </View>
            );
          }}
        ></FlatList>
      </View>
      <StatusBar translucent={false} style="auto" backgroundColor="white" />
      <Pressable
          style={{
            alignItems: "center",
            justifyContent: "center",
            paddingVertical: 12,
            paddingHorizontal: 32,
            borderRadius: 10,
            backgroundColor: "#243a70",
            margin: 20,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              lineHeight: 21,
              fontWeight: "bold",
              letterSpacing: 0.25,
              color: "white",
            }}
          >
            Proceed
          </Text>
        </Pressable>
    </View>
  );
}

export default SixthSlide;

const styles = StyleSheet.create({
  text: {
    fontSize: 20,
    fontWeight: "900",
    paddingLeft: 4,
    paddingTop: 7,
  },
  container: {
    marginLeft: 10,
    marginTop: 20,
    orderWidth: 2,
    borderColor: "#AAAA9F",
  },
  menu: {
    marginStart: 30,
    marginTop: 10,
  },
  Image: {
    width: 20,
    height: 20,
  },
});
