import { StatusBar } from "expo-status-bar";
import React from "react";
import { Image, StyleSheet, TextInput, TouchableOpacity } from "react-native";
import { View } from "react-native";
import { Text } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import header from "./header_common.png";
import right from "./vehicle_right.png";
import left from "./vehicle_left.png";
import logo from "./1280px-TVS_SCS_Logo-removebg-preview.png";

const FirstSlide = () => {
  return (
    <View width="100%" height="100%" style={{backgroundColor: "#f5f5f5"}}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginEnd: 35,
          marginVertical: 15,
        }}
      >
        <TouchableOpacity style={styles.menu}>
          <Ionicons name={"ios-menu"} size={30} />
        </TouchableOpacity>
        <Image style={{ width: 50, height: 50 }} source={logo}></Image>
      </View>
      <View style={{ flex: 1, justifyContent: "center" }}>
        <Image style={styles.Image} source={header}></Image>
        <Text style={styles.adminText}>admin admin</Text>
      </View>
      <View
        style={{ flex: 2, justifyContent: "flex-start", alignItems: "center" }}
      >
        <View>
          <TouchableOpacity>
            <Text style={styles.text}>
              Dispatch<Text>     </Text>
              <Image style={{ width: 25, height: 25 }} source={right}></Image>
            </Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={styles.text}>
            Recieve
              <Text>       </Text>
              <Image style={{ width: 25, height: 25 }} source={left}></Image>
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <StatusBar translucent={false} style="auto" backgroundColor="white" />
    </View>
  );
};

export default FirstSlide;

const styles = StyleSheet.create({
  text: {
    fontSize: 20,
    fontWeight: "900",
    borderWidth: 1,
    borderRadius: 15,
    borderColor: "#AAAA9F",

    padding: 20,
    marginVertical: 8,
    backgroundColor: "white",
  },
  adminText: {
    fontWeight: "900",
    fontSize: 20,
    alignSelf: "center",
  },
  Image: {
    width: 50,
    height: 50,
    alignSelf: "center",
  },
  menu: {
    marginStart: 20,
  },
});
